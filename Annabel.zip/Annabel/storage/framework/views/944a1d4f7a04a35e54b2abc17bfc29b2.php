<?php $__env->startSection('content'); ?>

<div class="container py-5">
    <div class="d-flex justify-content-between align-items-center">
        <h1>Products</h1>
        <a class="btn btn-success" href="<?php echo e(url('/create')); ?>">Create New Product</a>
    </div>

    <table class="table table-bordered">
        <thead>
            <tr>
            <th scope="col">No</th>
            <th scope="col">Name</th>
            <th scope="col">Price (RM)</th>
            <th scope="col">Details</th>
            <th scope="col">Publish</th>
            <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($key+1); ?></td>
                    <td><?php echo e($product->name); ?></td>
                    <td><?php echo e($product->price); ?></td>
                    <td><?php echo e($product->details); ?></td>
                    <td><?php if($product->publish == 1): ?> Yes <?php else: ?> No <?php endif; ?></td>
                    <td>
                        <a href="/<?php echo e($product->id); ?>"class="btn btn-info text-white">Show</a>
                        <a href="/<?php echo e($product->id); ?>/edit" class="btn btn-primary text-white">Edit</a>
                        <a href="/<?php echo e($product->id); ?>/delete" class="btn btn-danger text-white">Delete</a>
                    </td>
                </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\shoope\productcrud\resources\views/welcome.blade.php ENDPATH**/ ?>