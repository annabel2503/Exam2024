<?php $__env->startSection('content'); ?>

<div class="container py-5">

    <div class="d-flex justify-content-between align-items-center">
        <h1>Show Product</h1>
        <a class="btn btn-success" href="<?php echo e(url('/')); ?>">Back</a>
    </div>

    <form>
        <div class="form-group">
            <div><b>Name</b> : <span class="mb-0"><?php echo e($product->name); ?></span></div>
        </div>
        <div class="form-group">
            <div><b>Price (RM)</b> : <span class="mb-0"><?php echo e($product->price); ?></span></div>
        </div>
        <div class="form-group">
            <div><b>Details</b> : <span class="mb-0"><?php echo e($product->details); ?></span></div>
        </div>
        <div class="form-group">
            <div><b>Publish</b> : <span class="mb-0"><?php if($product->publish == 1): ?> Yes <?php else: ?> No <?php endif; ?></span></div>
        </div>
    </form>

</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\shoope\productcrud\resources\views/show.blade.php ENDPATH**/ ?>