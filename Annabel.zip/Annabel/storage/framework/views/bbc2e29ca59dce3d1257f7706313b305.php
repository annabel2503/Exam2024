<?php $__env->startSection('content'); ?>

<div class="container py-5">
    <div class="d-flex justify-content-between align-items-center">
        <h1>Add New Product</h1>
        <a class="btn btn-success" href="<?php echo e(url('/')); ?>">Back</a>
    </div>

    <form action="<?php echo e(url('/create')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="" class="form-label">Name</label>
            <input type="text" name="name" class="form-control" placeholder="Enter Name" required>
        </div>
        <div class="form-group">
            <label for="" class="form-label">Price (RM)</label>
            <input type="number" name="price" class="form-control" value="0" required>
        </div>
        <div class="form-group">
            <label for="" class="form-label">Details</label>
            <textarea name="details" cols="30" rows="10" class="form-control" placeholder="Enter Details" required></textarea>
        </div>
        <div class="form-group">
            <label for="" class="form-label">Publish</label>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="publish" value="1">
                <label class="form-check-label" for="flexRadioDefault1">
                  Yes
                </label>
              </div>
              <div class="form-check">
                <input class="form-check-input" type="radio" name="publish" checked value="0">
                <label class="form-check-label" for="flexRadioDefault2">
                  No
                </label>
              </div>
        </div>

        <div class="form-group">
            <button class="btn btn-primary" type="submit">Submit</button>
        </div>
    </form>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\shoope\productcrud\resources\views/create.blade.php ENDPATH**/ ?>