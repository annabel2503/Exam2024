@extends('layouts.layouts')

@section('content')

<div class="container py-5">
    <div class="d-flex justify-content-between align-items-center">
        <h1>Products</h1>
        <a class="btn btn-success" href="{{url('/create')}}">Create New Product</a>
    </div>

    <table class="table table-bordered">
        <thead>
            <tr>
            <th scope="col">No</th>
            <th scope="col">Name</th>
            <th scope="col">Price (RM)</th>
            <th scope="col">Details</th>
            <th scope="col">Publish</th>
            <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($products as $key => $product)
                <tr>
                    <td>{{$key+1}}</td>
                    <td>{{$product->name}}</td>
                    <td>{{$product->price}}</td>
                    <td>{{$product->details}}</td>
                    <td>@if ($product->publish == 1) Yes @else No @endif</td>
                    <td>
                        <a href="/{{$product->id}}"class="btn btn-info text-white">Show</a>
                        <a href="/{{$product->id}}/edit" class="btn btn-primary text-white">Edit</a>
                        <a href="/{{$product->id}}/delete" class="btn btn-danger text-white">Delete</a>
                    </td>
                </tr>

            @endforeach
        </tbody>
    </table>
</div>


@endsection
