<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;

class ProductController extends Controller
{
    public function index()
    {
        $products = Product::all();
        return view('welcome', compact('products'));
    }

    public function create()
    {
        return view('create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'price' => 'required',
            'details' => 'required',
            'publish' => 'required'
        ]);

        Product::create($request->all());
        return redirect('/');
    }

    public function show($id)
    {
        $product = Product::find($id);
        return view('show', compact('product'));
    }

    public function edit($id)
    {
        $product = Product::find($id);
        return view('edit', compact('product'));
    }


    public function update(Request $request, $id)
    {
        $request->validate([
            'name' => 'required',
            'price' => 'required',
            'details' => 'required',
            'publish' => 'required'
        ]);

        Product::where('id',$id)->update(Arr::except($request->all(), ['_token','_method']));
        return redirect('/');
    }

    public function delete($id)
    {
        Product::where('id',$id)->delete();
        return redirect('/');
    }
}
